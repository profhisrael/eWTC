<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class My_model extends CI_Model 
{
	function insertData($table,$data)
	{
		$this->db->insert($table,$data);
	}
	function getData($table,$resultType = 'result_array',$arg=[])
	{
		if(isset($arg['select']))
		{
			$this->db->select($arg['select']);
		}
		if(isset($arg['where']))
		{
			$this->db->where($arg['where']);
		}
		if(isset($arg['join']))
		{
			$this->db->join($arg['join']['table'], $arg['join']['query'], $arg['join']['type']);
		}
		if (isset($arg['group']))
		{
			$this->db->group_by($arg['group']['col']);
		}
		if (isset($arg['order']))
		{
			$this->db->order_by($arg['order']['col'],$arg['order']['type']);
        }
        if (isset($arg['like']))
        {
			$this->db->like($arg['like']['col'],$arg['like']['query']);
		}
		if (isset($arg['limit']))
        {
			$this->db->limit($arg['limit']['upto']);
		}
		if ($resultType=="result_array")
		{
			$return=$this->db->get($table)->result_array();
		}
		else if($resultType=="row_array")
		{
			$return=$this->db->get($table)->row_array();
		}
		else if($resultType=="result")
		{
			$return=$this->db->get($table)->result();
		}
		else if($resultType=="count_all_results")
		{
			$return=$this->db->count_all_results($table);
		}
		return $return; 
	}
	function updateData($table,$data,$where=false)
	{
		if($where!==false)
		{
			$this->db->where($where);
		}
		$this->db->update($table,$data);
	}
	function deleteData($table,$data)
	{
		$this->db->delete($table,$data);
	}
}
