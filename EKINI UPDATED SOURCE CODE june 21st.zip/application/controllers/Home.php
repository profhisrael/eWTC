<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		//Load user model
        $this->load->model('my_model');
		$this->load->library('form_validation');
	}
	public function index()
	{
		$data['course'] = $this->my_model->getData('tblcourse',$resultType = 'result_array',$arg=['limit'=>['upto'=>12]]);
		$data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'result_array',$arg=['limit'=>['upto'=>9]]);
		$data['brochure'] = $this->my_model->getData('tblbrochure',$resultType = 'result_array',$arg=[]);
		$data['gallery'] = $this->my_model->getData('tblgallery',$resultType = 'result_array',$arg=[]);
		$this->load->view('home/home',$data);		
	}
	public function downloadFile()
	{
		$id = $this->uri->segment('3');
		 if(!empty($id)){
            //load download helper
            $this->load->helper('download');
            
            //get file info from database
            $fileInfo = $this->my_model->getData('tblbrochure',$resultType="row_array",$arg=['select'=>['file','id'],'where'=>['id'=>$id]]);
           
            //file path
            $file = FCPATH.'assets/uploads/brochure/'.$fileInfo['file'];
         	
         	$data = file_get_contents($file);

         	$name = $fileInfo['file'];
            //download file from directory
            force_download($name, $data);
        }
	}
	public function about()
	{
		$data['about'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('home/about',$data);		
	}
	public function term()
	{
		$data['term'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('home/term-condition',$data);		
	}
	public function service()
	{
		$data['service'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('home/service',$data);		
	}
		public function faq()
	{
		$data['faq'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('home/faq',$data);		
	}
	
		public function policy()
	{
		$data['policy'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('home/privacy-policy',$data);		
	}
	public function singlecourse()
	{
	    $id = $this->uri->segment('3');
 		$data['course'] = $this->my_model->getData('tblcourse',$resultType = 'row_array',$arg=['where'=>['id'=>$id]]);
 		$this->load->view('home/singlecourse',$data);		
	}
	public function sendApplication()
	{
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $number = $this->input->post('number');
        $subjectmsg = $this->input->post('subject');
        $txtmsg = $this->input->post('message');
    	$error="";
    	if(empty($name))
	    {
	        $error .="Name is required\n";
	    }
	    if(empty($email))
	    {
	        $error .="Email is required\n";
	    }
	     if(empty($number))
	    {
	        $error .="Phone Number is required\n";
	    }
	    if(empty($subjectmsg))
	    {
	        $error .="Subject is required\n";
	    }
	    if(empty($txtmsg))
	    {
	        $error .="Message is required\n";
	    }
	    if(!empty($error))
	    {
	        responseGenerate(0,$error);
	    }
        
    	$to = "profhisrael@gmail.com"; //bukunsport@gmail.com
    	$subject = $subjectmsg;
        $message = $txtmsg;
        $headers = "From:".$email;
        
        $this->load->library('email');
        
        //cofermation email end
        $config['protocol'] = 'sendmail';
        $config['mailpath'] = '/usr/sbin/sendmail';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';

        $this->email->initialize($config);
        $this->email->from($email,$name);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

     	$res = $this->email->send();
    	
    	if(1)
    	{
    	    $insertdata = [
			'name' =>  $name,
			'email' => $email,
			'number' => $number,
			'subject' => $subjectmsg,
			'message' => $txtmsg,
			'date' => date('Y:m:d'),
			];
		    if(!$this->my_model->insertData('tblapplication',$insertdata))
		    {
                responseGenerate(1,'Message sent successfully, you will receive Message from us soon');
		    }else
		    {
		       responseGenerate(0,'Mail not sent. Try again!');
		    }    	
		}
    	else
    	{
    	    responseGenerate(0,'Mail not sent. Try again!');
    	}
    	
	}
	public function sendContact()
	{
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $number = $this->input->post('number');
        $subjectmsg = $this->input->post('subject');
        $txtmsg = $this->input->post('message');
    	$error="";
    	if(empty($name))
	    {
	        $error .="Name is required\n";
	    }
	    if(empty($email))
	    {
	        $error .="Email is required\n";
	    }
	     if(empty($number))
	    {
	        $error .="Phone Number is required\n";
	    }
	    if(empty($subjectmsg))
	    {
	        $error .="Subject is required\n";
	    }
	    if(empty($txtmsg))
	    {
	        $error .="Message is required\n";
	    }
	    if(!empty($error))
	    {
	        responseGenerate(0,$error);
	    }
        
    	$to = "profhisrael@gmail.com"; //bukunsport@gmail.com
    	$subject = $subjectmsg;
        $message = $txtmsg;
        $headers = "From:".$email;
        
        $this->load->library('email');
        
        //cofermation email end
        $config['protocol'] = 'sendmail';
        $config['mailpath'] = '/usr/sbin/sendmail';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';

        $this->email->initialize($config);
        $this->email->from($email,$name);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

     	$res = $this->email->send();
    	
    	if(1)
    	{
    	    $insertdata = [
			'name' =>  $name,
			'email' => $email,
			'number' => $number,
			'subject' => $subjectmsg,
			'message' => $txtmsg,
			'date' => date('Y:m:d'),
			];
		    if(!$this->my_model->insertData(' tblcontact',$insertdata))
		    {
                responseGenerate(1,'Message sent successfully, you will receive Message from us soon');
		    }else
		    {
		       responseGenerate(0,'Mail not sent. Try again!');
		    }    	
		}
    	else
    	{
    	    responseGenerate(0,'Mail not sent. Try again!');
    	}
    	
	}
	public function mail()
	{
	    $name = "Profhisrael";
	    $from = "profhisrael@gmail.com";
    	$to = "profhisrael@gmail.com"; //bukunsport@gmail.com
    	$subject = "subject";
        $message = "message";
         $headers = "From:" . $from;
    //     $this->load->library('email');   
    //     $config = array();
    //     $config['protocol']     = "smtp"; // you can use 'mail' instead of 'sendmail or smtp'
    //     $config['smtp_host']    = "ssl://smtp.googlemail.com";// you can use 'smtp.googlemail.com' or 'smtp.gmail.com' instead of 'ssl://smtp.googlemail.com'
    //     $config['smtp_user']    = "expansio@expansioncybertech.com"; //client email gmail id
    //     $config['smtp_pass']    = "CHq51-0v-aG0uW"; // client password
    //     $config['smtp_port']    =  465;
    //     $config['smtp_crypto']  = 'ssl';
    //     $config['smtp_timeout'] = "";
    //     $config['mailtype']     = "html";
    //     $config['charset']      = "iso-8859-1";
    //     $config['newline']      = "\r\n";
    //     $config['wordwrap']     = TRUE;
    //     $config['validate']     = FALSE;
    //     $this->load->library('email', $config); 
    //  	$res = $this->email->send(FALSE);
//     while(true) {
//   $res = mail($to,$subject,$message,$headers);
// }

//     	var_dump($res);
	}
	public function sendCV()
	{
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $subject = $this->input->post('subject');
    	$error="";
    	if(empty($name))
	    {
	        $error .="Name is required\n";
	    }
	    if(empty($email))
	    {
	        $error .="Email is required\n";
	    }
	    if(empty($subject))
	    {
	        $error .="Phone Number is required\n";
	    }
	    if(isset($_FILES["file"]["name"]))
	    {
	         $photo =  $_FILES["file"]["name"];
	    }
	    else
	    {
	        $error .="CV is required\n";
	    }
	    if(!empty($error))
	    {
	        responseGenerate(0,$error);
	    }
	    $config['upload_path'] = './assets/uploads/cv/';  
    	$config['allowed_types'] = 'pdf|txt|docx|doc|pptx|ppt|xlx|xl';  
    	$this->load->library('upload', $config);  
    	if(!$this->upload->do_upload('file'))  
        {  
         	$error=  $this->upload->display_errors(); 
         	responseGenerate(0,$error);
        }
    	else
    	{
    	    $picturedata = $this->upload->data();
    		$imagename = $picturedata['file_name'];
    	}	
    	    $insertdata = [
			'name' =>  $name,
			'email' => $email,
			'number' => $subject,
			'cv' => $imagename,
			'date' => date('Y:m:d'),
			];
		    if(!$this->my_model->insertData('tblcv',$insertdata))
		    {
                responseGenerate(1,'Data is saved successfully');
		    }else
		    {
		       responseGenerate(0,'Something Went Wrong. Try again!');
		    }    	

	}
	public function allcourses()
	{
		$data['course'] = $this->my_model->getData('tblcourse',$resultType = 'result_array',$arg=[]);
		$this->load->view('home/allcourse',$data);		
	}
	public function singlevacancy()
	{
	    $id = $this->uri->segment('3');
 		$data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'row_array',$arg=['where'=>['id'=>$id]]);
 		$this->load->view('home/singlevacancy',$data);		
	}
	public function allvacancy()
	{
		$data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'result_array',$arg=[]);
		$this->load->view('home/allvacancy',$data);		
	}
	public function loadContact()
	{
		$this->load->view('home/contact');		
	}
}