<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		//Load user model
        $this->load->model('my_model');
		$this->load->library('form_validation');
	}
	public function index()
	{
		if(checkAdminsession())
		{	
            $data['coures'] = $this->my_model->getData('tblcourse',$resultType = 'count_all_results',$arg=[]);
            $data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'count_all_results',$arg=[]);
            $data['application'] = $this->my_model->getData('tblapplication',$resultType = 'count_all_results',$arg=['where'=>['date'=>date('Y:m:d')]]);
            $data['cv'] = $this->my_model->getData('tblcv',$resultType = 'count_all_results',$arg=['where'=>['date'=>date('Y:m:d')]]);
            $data['contact'] = $this->my_model->getData('tblcontact',$resultType = 'result_array',$arg=[]);
			$this->load->view('admin/dashboard',$data);
		}
		else
		{
			$this->load->view('admin/login');
		}
	}
	public function loginProcess()
	{
		if(checkAdminsession())
		{	
			redirect('admin');
		}
		$this->form_validation->set_rules('email', 'Email','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required');

		if ($this->form_validation->run() == FALSE)
        {
			$this->load->view('admin/login',$data);
        }
        else
        {
	        $email = $this->input->post('email');
	        $password = $this->input->post('password');
			
			$data = $this->my_model->getData('tbladmin',$resultType = 'row_array',$arg=['where'=>['email'=>$email,'password'=>$password]]);
			if(!empty($data))
			{
				$session = [
					'adminid' => $data['id'],
					'adminemail' => $data['email'],
					'adminphoto' => $data['image'],
				];

				$this->session->set_userdata($session);
				redirect('admin');
			}
			else
			{
				$this->session->set_flashdata('adminInvalidmsg','Invalid Email Or Password');
				$this->load->view('admin/login');
			}	
			 
        }
	}
	public function logoutProcess()
	{
		$this->session->sess_destroy();
		$this->session->set_flashdata('adminlogoutmsg','Successfully Log-Out');
		$this->load->view('admin/login');
	}
	public function loadAboutpage()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
	    $data['aboutcontent'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('admin/about',$data);
	}

	public function insertAboutcontent()
	{
	    if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = "";
		$id = trim($this->input->post('id'));
		$textareaVal = trim($this->input->post('textareaVal'));
		if(empty($textareaVal))
		{
			$error.="About Us Content Can't Be Empty";
		}
		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
		$updatedate = [
			'aboutpage' => $textareaVal
		];
	
		if(!$this->my_model->updateData('tblpage',$updatedate,['id'=>$id]))
		{
			responseGenerate(1,"Data is Saved Successfully");
		}
		else
		{
			responseGenerate(0,"Something Went Wrong! Try again");
		}
	}
	public function loadAddcourse()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
    	$this->load->view('admin/addcourse');
	}
	public function insertCourse()
	{
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = "";
		$name = trim($this->input->post('name'));
	    $location= $this->input->post('location');
	    $fromdate = trim($this->input->post('fromdate'));
	    $todate = trim($this->input->post('todate'));
	    $content = trim($this->input->post('content'));

		if(empty($name))
		{
			$error.="Name Can't Be Empty";
		}
		if(empty($location))
		{
			$error.="location Can't Be Empty\n";
		}
		if(empty($fromdate))
		{
			$error.="From date Can't Be Empty\n";
		}
		if(empty($todate))
		{
			$error.="To date Can't Be Empty";
		}
		if(empty($content))
		{
			$error.="Content Can't Be Empty";
		}
		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
	    $photo =  $_FILES["image"]["name"];
		$config['upload_path'] = './assets/uploads/course/';  
    	$config['allowed_types'] = 'jpg|jpeg|png|gif';  
    	$this->load->library('upload', $config);  
    	if(!$this->upload->do_upload('image'))  
        {  
         	$error=  $this->upload->display_errors(); 
         	responseGenerate(0,$error);
        }
    	else
    	{
    	    $picturedata = $this->upload->data();
    		$imagename = $picturedata['file_name'];
    		$insertdata = [
    			'name'=>$name,
    			'location'=>$location,
    			'fromdate'=>$fromdate,
    			'todate'=>$todate,
    			'content'=>$content,
    			'image'=>$imagename    
    		];
    	
    		if(!$this->my_model->insertData('tblcourse',$insertdata))
			{
			   responseGenerate(1,'Data is inserted successfully');
			}
			else
			{
			    responseGenerate(0,'Something went wrong .try again');
			}
    	} 
	}
	public function loadCourses()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['course'] = $this->my_model->getData('tblcourse',$resultType = 'result_array',$arg=[]);
		 $this->load->view("admin/viewcourses",$data);	
	}
	public function deleteCourse()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblcourse',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function deleteContact()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblcontact',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function editCourse($id)
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->uri->segment('3');
		$data['course'] = $this->my_model->getData('tblcourse',$resultType = 'row_array',$arg=['where'=>['id'=>$id]]);
		 $this->load->view("admin/editcourse",$data);	
	}
	public function updateCourse()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = "";
		$id = trim($this->input->post('id'));
		$name = trim($this->input->post('name'));
	    $location= $this->input->post('location');
	    $fromdate = trim($this->input->post('fromdate'));
	    $todate = trim($this->input->post('todate'));
	    $content = trim($this->input->post('content'));
		if(empty($name))
		{
			$error.="Name Can't Be Empty";
		}
		if(empty($location))
		{
			$error.="location Can't Be Empty\n";
		}
		if(empty($fromdate))
		{
			$error.="From date Can't Be Empty\n";
		}
		if(empty($todate))
		{
			$error.="To date Can't Be Empty";
		}
		if(empty($content))
		{
			$error.="Content Can't Be Empty";
		}

		if(isset($_FILES['image']) && !empty($_FILES['image']))
	    {
	        $config['upload_path'] = './assets/uploads/course/';  
        	$config['allowed_types'] = 'jpg|jpeg|png|gif';  
        	$this->load->library('upload', $config);  
        	if(!$this->upload->do_upload('image'))  
            {  
             	$error=  $this->upload->display_errors(); 
             	responseGenerate(0,$error);
            }
        	else
        	{
        	    $picturedata = $this->upload->data();
        		$imagename = $picturedata['file_name'];
        	}
	    }
	    else
	    {   
	        $imagename = $this->input->post('photovalue');
	    }

		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
		
		$updatedata = [
			'name'=>$name,
			'location'=>$location,
			'fromdate'=>$fromdate,
			'todate'=>$todate,
			'content'=>$content,
			'image'=>$imagename    
		];
	
		if(!$this->my_model->updateData('tblcourse',$updatedata,['id'=>$id]))
		{
		   responseGenerate(1,'Data is updated successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}	
	public function loadTermconditionpage()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
	    $data['termconditioncontent'] = $this->my_model->getData('tblpage',$resultType = 'row_array',$arg=[]);
		$this->load->view('admin/termcondition',$data);
	}
	public function insertTermconditioncontent()
	{
	    if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = "";
		$id = trim($this->input->post('id'));
		$textareaVal = trim($this->input->post('textareaVal'));
		if(empty($textareaVal))
		{
			$error.="Term & Condition Content Can't Be Empty";
		}
		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
		$updatedate = [
			'termconditioncontentpage' => $textareaVal
		];
	
		if(!$this->my_model->updateData('tblpage',$updatedate,['id'=>$id]))
		{
			responseGenerate(1,"Data is Saved Successfully");
		}
		else
		{
			responseGenerate(0,"Something Went Wrong! Try again");
		}
	}
	public function loadGallery()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['gallery'] = $this->my_model->getData('tblgallery',$resultType = 'result_array',$arg=[]);
		$this->load->view('admin/gallery',$data);
	}
	public function uploadGallery()
    {
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
        $image = array();
        $error = "";
        if (empty($_FILES['images']['name']))
    	{
		   $message = "Please select the image to upload";
		   responseGenerate(0,$error);
    	}
        else
        {

            $ImageCount = count($_FILES['images']['name']);
            for($i = 0; $i < $ImageCount; $i++)
            {
                $_FILES['file']['name']       = $_FILES['images']['name'][$i];
                $_FILES['file']['type']       = $_FILES['images']['type'][$i];
                $_FILES['file']['tmp_name']   = $_FILES['images']['tmp_name'][$i];
                $_FILES['file']['error']      = $_FILES['images']['error'][$i];
                $_FILES['file']['size']       = $_FILES['images']['size'][$i];
    
                // File upload configuration
                $uploadPath = './assets/uploads/gallery/';
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
    			
                // Load and initialize upload library
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
    
                // Upload file to server
                if($this->upload->do_upload('file'))
                {
                    // Uploaded file data
                    $imageData = $this->upload->data();
                    $uploadImgData[$i]['image'] = $imageData['file_name'];
                }
                else
                {
                    $error = $this->upload->display_errors();
                    responseGenerate(0,$error);
                }
            
            }
            if(!empty($uploadImgData))
            {
                // Insert files data into the database
                if($this->db->insert_batch('tblgallery',$uploadImgData))
                {
                	responseGenerate(1,"Data is Saved Successfully");
                }
                else
                {
                	responseGenerate(0,"Something Went Wrong! Try again");
                }  
            }
        }
    }
    public function deleteGallery()
    {
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblgallery',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
    }
    public function loadProfile()
    {
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->session->userdata('adminid');
		$data['profile'] = $this->my_model->getData('tbladmin',$resultType = 'row_array',$arg=['where'=>['id'=>$id]]);
		$this->load->view('admin/profile',$data);
    }
    public function updateprofileinfo()
	{
	    if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = '';
		$name = trim($this->input->post('name'));
		$address = trim($this->input->post('address'));
		$phone = trim($this->input->post('phone'));
		$password = trim($this->input->post('password'));
		$email = trim($this->input->post('email'));
		if(empty($name))
		{
			$error.="Name Can't Be Empty";
		}
		if(empty($address))
		{
			$error.="Address Can't Be Empty";
		}
		if(empty($phone))
		{
			$error.="Phone Can't Be Empty";
		}
		if(empty($password))
		{
			$error.="Password Can't Be Empty";
		}
		if(empty($email))
		{
			$error.="Email Can't Be Empty";
		}

		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
		$updatedate = [
			'name' => $name,
			'address' => $address,
			'phone' => $phone,
			'password' => $password,
			'email' => $email,
		];
		$id = $this->session->userdata('adminid');
		if(!$this->my_model->updateData('tbladmin',$updatedate,['id'=>$id]))
		{
			responseGenerate(1,"Data is Saved Successfully");
		}
		else
		{
			responseGenerate(0,"Something Went Wrong! Try again");
		}
	}
	public function updateprofilepicture()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		if(isset($_FILES['image']) && !empty($_FILES['image']))
	    {
	        $config['upload_path'] = './assets/uploads/profile/';  
        	$config['allowed_types'] = 'jpg|jpeg|png|gif';  
        	$this->load->library('upload', $config);  
        	if(!$this->upload->do_upload('image'))  
            {  
             	$error=  $this->upload->display_errors(); 
             	responseGenerate(0,$error);
            }
        	else
        	{
        	    $picturedata = $this->upload->data();
        		$imagename = $picturedata['file_name'];
        	}
        	$updatedate = [
			'image' => $imagename,
		];
		$id = $this->session->userdata('adminid');
		if(!$this->my_model->updateData('tbladmin',$updatedate,['id'=>$id]))
		{
			responseGenerate(1,"Data is Saved Successfully");
		}
		else
		{
			responseGenerate(0,"Something Went Wrong! Try again");
		}
	    }
	    else
	    {   
	        responseGenerate(0,"Picture is not uploaded");
	    }
	}
	public function loadBrochure()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['brochure'] = $this->my_model->getData('tblbrochure',$resultType = 'result_array',$arg=[]);
		$this->load->view('admin/brochure',$data);
	} 
	public function insertBrochure()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$this->db->select();
		$query = $this->db->get('tblbrochure');
		$cnt = $query->num_rows();

		if($cnt < 4)
		{
			$error = '';
			$baname = trim($this->input->post('baname'));
			if(empty($baname))
		    {
		        $error .="Brochure name is required\n"."<br>";
		    }

		    if(isset($_FILES["file"]["name"]))
		    {
		         $photo =  $_FILES["file"]["name"];
		    }
		    else
		    {
		        $error .="Brochure File is required\n"."<br>";
		    }

		    if(!empty($error))
		    {
		        responseGenerate(0,$error);
		    }

		    $config['upload_path'] = './assets/uploads/brochure/';  
	    	$config['allowed_types'] = 'pdf|txt|docx|doc|pptx|ppt|xlx|xl';  
	    	$this->load->library('upload', $config);  
	    	if(!$this->upload->do_upload('file'))  
	        {  
	         	$error=  $this->upload->display_errors(); 
	         	responseGenerate(0,$error);
	        }
	    	else
	    	{
	    	    $picturedata = $this->upload->data();
	    		$filename = $picturedata['file_name'];
	    		
	    		$insertdata = [
	    		    'name' => $baname,
	    		    'file' => $filename,
	    		];
	    	
	    		if(!$this->my_model->insertData('tblbrochure',$insertdata))
				{
					responseGenerate(1,'Data is saved successfully');
				}
				else
				{
				    responseGenerate(0,'Something went wrong .try again');
				}
			}
		}
		else
		{
			responseGenerate(0,'Exceed You limit');
		}		
	}
	public function downloadFile()
	{
		$id = $this->uri->segment('3');
		 if(!empty($id)){
            //load download helper
            $this->load->helper('download');
            
            //get file info from database
            $fileInfo = $this->my_model->getData('tblbrochure',$resultType="row_array",$arg=['select'=>['file','id'],'where'=>['id'=>$id]]);
           
            //file path
            $file = FCPATH.'assets/uploads/brochure/'.$fileInfo['file'];
         	
         	$data = file_get_contents($file);

         	$name = $fileInfo['file'];
            //download file from directory
            force_download($name, $data);
        }
	}
	public function downloadCV()
	{
		$id = $this->uri->segment('3');
		 if(!empty($id)){
            //load download helper
            $this->load->helper('download');
            
            //get file info from database
            $fileInfo = $this->my_model->getData('tblcv',$resultType="row_array",$arg=['select'=>['cv','id'],'where'=>['id'=>$id]]);
           
            //file path
            $file = FCPATH.'assets/uploads/cv/'.$fileInfo['cv'];
         	
         	$data = file_get_contents($file);

         	$name = $fileInfo['file'];
            //download file from directory
            force_download($name, $data);
        }
	}
	public function deleteBrochure()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblbrochure',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function loadAddvacancy()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
    	$this->load->view('admin/addvacancy');
	}
	public function insertVacancy()
	{
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$error = "";
		$title = trim($this->input->post('title'));
	    $content = trim($this->input->post('content'));

		if(empty($title))
		{
			$error.="Title Can't Be Empty";
		}
		if(empty($content))
		{
			$error.="Content Can't Be Empty";
		}
		if(!empty($error))
		{
			responseGenerate(0,$error);
		}
	    $photo =  $_FILES["image"]["name"];
		$config['upload_path'] = './assets/uploads/vacancy/';  
    	$config['allowed_types'] = 'jpg|jpeg|png|gif';  
    	$this->load->library('upload', $config);  
    	if(!$this->upload->do_upload('image'))  
        {  
         	$error=  $this->upload->display_errors(); 
         	responseGenerate(0,$error);
        }
    	else
    	{
    	    $picturedata = $this->upload->data();
    		$imagename = $picturedata['file_name'];
    		$insertdata = [
    			'title'=>$title,
    			'content'=>$content,
    			'image'=>$imagename,
    			'date'=>date('Y:m:d')
    		];
    	
    		if(!$this->my_model->insertData('tblvacancy',$insertdata))
			{
			   responseGenerate(1,'Data is inserted successfully');
			}
			else
			{
			    responseGenerate(0,'Something went wrong .try again');
			}
    	} 
	}
	public function loadAllvacancy()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'result_array',$arg=[]);
		$this->load->view("admin/viewvacancy",$data);	
	}
	public function deleteVacancy()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblvacancy',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function editVacancy($id)
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->uri->segment('3');
		$data['vacancy'] = $this->my_model->getData('tblvacancy',$resultType = 'row_array',$arg=['where'=>['id'=>$id]]);
		$this->load->view("admin/editvacancy",$data);	
	}
	public function updateVacancy()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}  
		$error = "";
		$id = trim($this->input->post('id'));
		$title = trim($this->input->post('title'));
	    $content = trim($this->input->post('content'));
	    
		if(empty($title))
		{
			$error.="Name Can't Be Empty";
		}
		if(empty($content))
		{
			$error.="Content Can't Be Empty";
		}
       
		if(isset($_FILES['image']) && !empty($_FILES['image']))
	    {
	        $config['upload_path'] = './assets/uploads/vacancy/';  
        	$config['allowed_types'] = 'jpg|jpeg|png|gif';  
        	$this->load->library('upload', $config);  
        	if(!$this->upload->do_upload('image'))  
            {  
             	$error=  $this->upload->display_errors(); 
             	responseGenerate(0,$error);
            }
        	else
        	{
        	    $picturedata = $this->upload->data();
        		$imagename = $picturedata['file_name'];
        	}
	    }
	    else
	    {   
	        $imagename = $this->input->post('photovalue');
	    }
          
		if(!empty($error))
		{
			responseGenerate(0,$error);
		}

		$updatedata = [
			'title'=>$title,
			'content'=>$content,
			'image'=>$imagename    
		];
		if(!$this->my_model->updateData('tblvacancy',$updatedata,['id'=>$id]))
		{
		   responseGenerate(1,'Data is updated successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function loadApplication()
	{
	    if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['application'] = $this->my_model->getData('tblapplication',$resultType = 'result_array',$arg=[]);
		$this->load->view("admin/listapplication",$data);
	}
	public function loadAllcv()
	{
    	if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$data['cv'] = $this->my_model->getData('tblcv',$resultType = 'result_array',$arg=[]);
		$this->load->view("admin/listcv",$data);	
	}
	public function deleteCV()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblcv',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
	public function deleteApplication()
	{
		if(!checkAdminsession())
		{	
			redirect('admin');
		}
		$id = $this->input->post('id');
		if(!$this->my_model->deleteData('tblapplication',['id'=>$id]))
		{
			responseGenerate(1,'Data is deleted successfully');
		}
		else
		{
		    responseGenerate(0,'Something went wrong .try again');
		}
	}
}
