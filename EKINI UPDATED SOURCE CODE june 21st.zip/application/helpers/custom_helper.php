<?php
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	function checkAdminsession()
	{
		$ci =& get_instance(); 
		if($ci->session->userdata('adminid') && $ci->session->userdata('adminemail'))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function checkUsersession()
	{
		$ci =& get_instance(); 
		if($ci->session->userdata('userid') && $ci->session->userdata('useremail'))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function responseGenerate($type,$msg="")
	{
		$result=['type'=>$type,'msg'=>$msg];
		echo json_encode($result);
		exit;
	}
	