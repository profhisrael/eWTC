<?php $this->load->view('home/header'); ?>


  <main id="main">
<br><br><br>
  <!-- ======= About Section ======= -->
        <div class="section-header"  style="margin-top: 8%;">
          <h2>Terms & Conditions</h2>
</div>
<!-- ======= About Section ======= -->
<div class="section-header">
      <div class="container">

 

          <div class="w3-container w3-padding">

                <?php if(!empty($term['termconditioncontentpage'])){ echo $term['termconditioncontentpage']; }?>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->


    

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>