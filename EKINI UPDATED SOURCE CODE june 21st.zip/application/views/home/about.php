<?php $this->load->view('home/header'); ?>
  <!-- ======= Intro Section ======= -->

  <main id="main">
    <br>
  <!-- ======= About Section ======= -->
        <div class="section-header" style="margin-top: 8%;">
          <h2>About Us </h2>
</div>
<!-- ======= About Section ======= -->
<div class="section-header">
    <section id="serv">
      <div class="container">

        <div class="row serv-cols">

          <div class="col-md-12 wow">
            <div class="serv-col">
                <?php if(!empty($about['aboutpage'])){ echo $about['aboutpage']; }?>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->





  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>