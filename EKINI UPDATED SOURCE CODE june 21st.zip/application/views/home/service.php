
<?php $this->load->view('home/header'); ?>
  <!-- ======= Intro Section ======= -->
<style>
html, body, h1, h2, h3, h4, h5, h6 {
  font-family: "Comic Sans MS", cursive, sans-serif;
}
</style>

  <main id="main">
    <br>
  <!-- ======= About Section ======= -->
        <div class="section-header w3-padding-top" style="margin-top: 8%;">
          <h2>Our Services</h2>
</div>


   <div class="w3-container w3-padding">
<div class="w3-border w3-border-red w3-half">
	<center><span class="fa fa-graduation-cap w3-jumbo" style="color:#060c22"></span><br><span class="w3-xlarge w3-text-red"><b>Training Programs</b></span>
	</center>

	<div class="w3-border-top w3-border-red">
		<div class="w3-padding w3-medium" style="background-color:#060c22; color:white;">Our Offering:</div>

<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Standard Stand Alone- Listed in our Brochure
</span>
<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Bundled Programming - 2 to 4 programs amalgamated,  depending on perceived needs, or audience profiling 
</span>


<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Client-Specific Programming- developed for a particular organisation after a brief/ Training Need Analysis. We believe this is the most effective programing

</span>

	</div>

</div>



<div class="w3-border w3-border-red w3-half">
	<center><span class="fa  fa-product-hunt w3-padding-top w3-jumbo" style="color:#060c22"></span><br><span class="w3-xlarge w3-text-red"><b>Programming range<br /></b></span>
	</center>

<div class="w3-border-top w3-border-red">
		</div>


<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Soft skills/Personal Development-Leadership Management
</span>
<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Personal/Organisational Effectiveness : team/teaming, Personal Effectiveness, Communication 
</span>

<span class="w3-padding fa fa-arrow-circle-o-right w3-large"> Retreat/Facilitation - of National Conferences, Sales conferences and sessions for brain storming, Corporate/Departmental re-invention, bonding, leadership, change, policy, strategy, motivation 

	<!--- ===== DID MANIPULATION HERE --->
	<span class="w3-btn w3-white w3-text-white w3-hover-white">Enroll for Our Training Now!</span>
<!--- ===== DID MANIPULATION HERE --->
</span>
</div>
</div></div><br>
<div class="w3-container w3-padding">

<center><div class="w3-xlarge"><b>WHY DO BUSINESS WITH US</b> <span class="fa fa-question-circle w3-text-indigo w3-xlarge"> </span></center><br>
	



	<div class="w3-third w3-padding">
<div class="w3-card-2 w3-round-jumbo">

<header class="w3-container w3-hover-shadow" style="background-color:#060c22;">
  <h6 class="w3-text-white" align="center">EXPERIENCED FACILITATORS</h6> 
</header>
<div class="w3-container">
 <span class="w3-padding fa fa-star"> Top-of-the-pack Faculty and facilitators</span><br>
 <span class="w3-padding fa fa-star"> Relevant experience and pedigree
</span><br>
 <span class="w3-padding fa fa-star"> We know the specific needs of the industry
</span><br>
<hr class="w3-bottombar w3-border-red">

Our leading consultants have over 50 years of combined cognate experience
   
<span>Trained/facilitated severally  with an overall participants in excess of  1200
delegates from <br><span class="fa fa-check-circle w3-text-green w3-padding"></span> First Bank <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>PZ plc <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Emzor <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Regency insurance plc <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Pharma-Deko plc <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Capital Bancorp <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Real Pharmaceuticals <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Miraflash <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>GSK <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Ranbaxy <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Fidson <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>P&G <br><span class="fa fa-check-circle w3-text-green w3-padding"></span>Mouka Foam etc
<center><span class="fa fa-level-down w3-xxlarge w3-text-pink"></span></center>
<h6>We  also have a pool of excellent  associates with relevant experience and training</h6>
<hr class="w3-bottombar w3-border-red">


</div>

</div>
</div>

	<div class="w3-third w3-padding">
<div class="w3-card-2 w3-round-jumbo">

<header class="w3-container w3-hover-shadow" style="background-color:#060c22;">
  <h6 class="w3-text-white" align="center">OUR CONTENT
</h6>
</header>
<div class="w3-container">
  <p align="justify" class="w3-padding">We believe and strive to offer practical, providing our clients/delegates with down-to-earth training programs geared towards clear and immediate result/improvement
<br><br><span>Program are designed to impact on profit, productivity and competence</span>
</p>
<p class="w3-padding" align="center"><span class="fa fa-thumbs-o-up w3-xxlarge w3-text-pink"></span><br> Our METHODS create client- tailored <br>programs, content and delivery:</p>

<span class="w3-half fa fa-str w3-padding w3-red"> CEO interactions<br><br> </span>
<span class="w3-half fa fa-str w3-padding w3-pink"> Management/Supervisor/
Stakeholder interviews</span>
<span class="w3-half fa fa-str w3-padding w3-indigo"> Service/market research/assessment<br><br></span>
<span class="w3-half fa fa-str w3-padding w3-yellow"> Market/Process Evaluation/Impact assessments</span>
<span class="w3-half fa fa-str w3-padding w3-green"> Delivery/intervention proposals and programs</span>
<span class="w3-half fa fa-str w3-padding w3-blue"> Post-training Reinforcement </span>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>

</div>
</div>


	<div class="w3-third w3-padding">
<div class="w3-card-2 w3-round-jubo">

<header class="w3-container w3-hover-shadow" style="background-color:#060c22;">
  <h6 class="w3-text-white" align="center">OUR DELIVERY
</h6>
</header>
<div class="w3-container">
  	<center><span class="w3-padding-top fa fa-file-powerpoint-o w3-text-orange w3-xxlarge"></span><h4 class=""><b>PowerPoint Presentation</b></h4> <p class="w3-medium w3-padding" align="justify"> <b>With the use of multi-media projector focused, attention riveting, easy understanding and learning</b></p>
</center>	


<center><span class="w3-padding-top fa fa-users w3-text-pink w3-xxlarge"></span><h4 class=""><b>Interactive</b></h4> <p class="w3-medium w3-padding" align="justify"> <b>Building on everybody’s experience and insight, learning from facilitators and from each other as well; stimulated practice</b></p>
</center>


<center><span class="w3-padding-top fa fa-laptop w3-text-indigo w3-xxlarge"></span><h4 class=""><b>Practical</b></h4> <p class="w3-medium w3-padding-top" align="justify"> <b>What is useful now, made easily applicable, relevant within our immediate environment, ingrained through activities/role playing</b></p>
</center> 


	<h4 align="center"><b>Empowering</b></h4>
	<p class="w3-medium w3-padding-top" align="center"> <b> Showing how, lead-me-by-the-hand simplicity </b></p>
</div>

	<h4 class="w3-padding-top" align="center"><b>Case studies and Exercises</b></h4>
	<p class="w3-medium w3-padding-top" align="center"> <b> Reinforcing learning and knowledge </b></p>
</div>





</div></div> 
</div>  


</div>

</div>
</div>







<br><br>
  
</div>
</center></div></div>
    

  <!-- End #main -->
<?php $this->load->view('home/footer'); ?>