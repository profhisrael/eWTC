<?php $this->load->view('home/header'); ?>
  <!-- ======= Intro Section ======= -->
  <section id="intro">
    <div class="intro-container wow fadeIn">
      <h1 class="mb-4 pb-0">EKINI WHITE TULIP <br><span>CONSULTING LIMITED</span></h1>
      <p class="mb-4 pb-0">Developing leaders and managers for today and tomorrow</p>
  
<!-- ====== Comment this place so as to add their youtube channel link if it is available or any video link-->
      <!--<a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
   
  --> 

     <a href="training.php" class="about-btn scrollto">Enroll Now</a>
    </div>
  </section><!-- End Intro Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2>About The eWTC</h2>
            <p align="justify">EKINI WHITE TULIP CONSULTING LIMITED is a business that rendered different services like Training of Stuents to be professional in marketing, technology and fundamental..... </p>
          </div>
          <div class="col-lg-3">
            <h2>Mission</h2>
            <p align="justify">To provide the highest quality services that best meet the needs of growing and forward looking organisations using the most up-to-date information, techniques and processes, through competent professionals with clear and demonstrable benefit to clients and all other stakeholders

</p>
          </div>
        <div class="col-lg-3">
            <h2>Vision</h2>
            <p align="justify">     To take human capital development to its pinnacle in Nigeria in particular and the African continent in general.
</p>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->

    <br>

  <!-- ======= Services Section ======= -->
        <div class="section-header">
          <h2>Our Services </h2>
</div>
<!-- ======= Services Section ======= -->
<div class="section-header">
    <section id="serv">
      <div class="container">

        <div class="row serv-cols">

          <div class="col-md-4">
            <div class="serv-col">
              <div class="img">
                <img src="assets/img/services/1.jpeg" alt="" class="img-fluid">
                <div class="icon"><span style="color:#060c22;" class="fa fa-flash w3-xxlarge""></span></div>
              </div>
              <h2 class="title">Commercial/Field Force Management Solutions </h2>
              <div align="justify" class="w3-padding">
                What is Field Force Management? Field Service Management (FSM), also known as Field Force Automation (FFA), is an attempt to optimize processes and information needed by companies who send technicians or staff "into the field" (or out of the office.)
              <br><br><br>
          </div>
              <center><span class="w3-btn w3-round-xxlarge w3-red"> Learn More <span class="fa fa-caret-right"></a> </span> </span></center>
              <br>

            </div>
          </div>

          <div class="col-md-4 wow">
            <div class="serv-col">
              <div class="img">
                <img src="assets/img/services/2.jpg" alt="" class="img-fluid" style="height:230px; width:100%;">
                <div class="icon"><span class="fa fa-spinner w3-xxlarge"></span></div>
              </div>
              <h2 class="title">Training and Human Capital Development</h2>
              <div align="justify" class="w3-padding">
                At the end of it all, we know adding value means helping you to save money, make more money or growing your business. In any and all assignments, these are our primary consideration. 
              </div><br><br><br><br>
              <center><span class="w3-btn w3-round-xxlarge w3-red"> Learn More <span class="fa fa-caret-right"> </span></span></center>
              <br>

            </div>
          </div>

          <div class="col-md-4 wow">
            <div class="serv-col">
              <div class="img">
                <img src="assets/img/services/3.jpg" alt="" class="img-fluid">
                <div class="icon"><span class="fa fa-check w3-xxlarge""></span></div>
              </div>
              <h2 class="title">Sales and Marketing Solution</h2>
              <div align="justify" class="w3-padding">
               Nemo enim ipsam voluptatem quia voluptas sit aut odit aut fugit, sed quia magni dolores eos qui ratione voluptatem sequi nesciunt Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.
              <br><br><br><br><br>
              </div>
              <center><span class="w3-btn w3-round-xxlarge w3-red"> Learn More <span class="fa fa-caret-right"> </span> </span></center>
              <br>

            </div>
          </div>

        </div>

      </div>
    </section><!-- End services Section -->

<!-- ======= brochure Section ======= -->
    <section id="brochure" class="brochure" style="background-color:#060c22;">
      <div class="container w3-padding">

        <div class="row">
          <?php foreach($brochure as $row){ ?>
          <div class="col-lg-3 col-md-6 w3-padding">
            <div class="brochure-box w3-round-large">
              <span class="fa fa-file-pdf-o "></span><a href="<?php echo base_url().'home/downloadFile/'.$row['id']; ?>">
             <span class="w3-small w3-padding"><?php echo $row['name'] ?></span>
            <button class="w3-btn w3-red w3-small w3-padding-top">Download</button></a>
            </div>
          </div>
        <?php } ?>
           
        </div>

      </div>
<br></section>
    <!-- ======= Training and upcoming Pogrammes ======= -->
    <section id="trainings" class="section-with-bg">

       <div class="container">
        <div class="section-header">
          <h2>Training & Upcoming Programmes</h2>

        </div>
        <div class="row">
          <?php foreach($course as $row){ ?>
          <div class="col-sm-6 col-md-3">
            <div class="training" style="    padding: 4%;">
              <div class="training-img">
                <img style="height: 250px;width: 100%;" src="<?php echo base_url().'assets/uploads/course/'.$row['image'] ?>" alt="training 1" class="img-fluid">
              </div>
              <h3 align="left" class="w3-padding-small w3-small"><a href="<?php echo base_url().'home/singlecourse/'.$row['id'] ?>"><b><?php echo $row['name'] ?></b></a></h3>
              <span class="fa fa-calendar w3-padding-small w3-lage w3-text-black w3-small"><b>
              <?php
              $fromdate = $row['fromdate'];
              $newfromdate = date("m-d-Y", strtotime($fromdate));
              $todate = $row['todate'];
              $newtodate = date("m-d-Y", strtotime($todate));
              echo $newfromdate."    ".$newtodate;
              ?></b></span>
              <span class="w3-padding-small w3-padding-top fa fa-location-arrow w3-lage w3-text-black w3-small"><b> Lagos</b></span><br>
              <div class="w3-padding-small w3-text- w3-padding-top w3-small" align="justify" style="background-color:#060c22; color:white;"><b>
             <?php
             echo "<spa class='text-white'>".substr($row['content'],0,200)."</strong>";
              ?></b></div><br>  
                <a href="<?php echo base_url().'home/singlecourse/'.$row['id'] ?>"><center><span class="w3-btn w3-red w3-round-xxlarge">Booking and Details</span></center><br>
                </a>
            </div>

          </div>
          <?php } ?>
          <div class="col-md-12 text-center">
                <a href="<?php echo base_url(); ?>home/allcourses"><button type="button" class="btn btn-primary">Load more</button></a>      
          </div>
        
<keep Doubling>

        </div>
      </div>

    </section><!-- End Training  -->


    <!-- ======= Vacancies======= --> <!--The vacancy willl be CAROUSEL ()-->
    <section id="Enroll-Now" class="section-with-bg">
      <div class="container">

        <div class="section-header">
          <h2>vacancies</h2>
          <p></p>
        </div>

        <div class="row">
        <?php foreach($vacancy as $row){ ?>
           <div class="col-sm-6 col-md-3">
            <div class="training" style="    padding: 4%;">
              <div class="training-img">
                <img style="height: 250px;width: 100%;" src="<?php echo base_url().'assets/uploads/vacancy/'.$row['image'] ?>" alt="training 1" class="img-fluid">
              </div>
              <h3 align="left" class="w3-padding-small w3-small"><a href="<?php echo base_url().'home/singlevacancy/'.$row['id'] ?>"><b><?php echo $row['title'] ?></b></a></h3>
              <div class="w3-padding-small w3-text- w3-padding-top w3-small" align="justify" style="background-color:#060c22; color:white;"><b>
              <?php
              echo "<strong class='text-white'>".substr($row['content'],0,30)."</strong>";
              ?></b></div><br>  
                <a href="<?php echo base_url().'home/singlevacancy/'.$row['id'] ?>"><center><span class="w3-btn w3-red w3-round-xxlarge">Apply and Details</span></center><br>
                </a>
            </div>

          </div>
        <?php } ?>
            <div class="col-md-12 text-center">
                <a href="<?php echo base_url(); ?>home/allvacancy"><button type="button" class="btn btn-primary">Load more</button></a>      
            </div>
        </div>
      </div>

    </section><!-- End Vacancy -->

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class=""  style="background-color:#060c22;">

      <div class="container">
        <div class="section-header">
          <h2 class="w3-text-white">Gallery</h2>
          <p>Check our gallery from the recent programme</p>
        </div>
      </div>

      <div class="owl-carousel gallery-carousel">
        <?php foreach($gallery as $row){ ?>
        <a href="<?php echo base_url().'assets/uploads/gallery/'.$row['image'];?>" class="venobox" data-gall="gallery-carousel"><img src="<?php echo base_url().'assets/uploads/gallery/'.$row['image'];?>" alt="">
        </a>
        <?php } ?>
    </section><!-- End Gallery Section -->

    <!-- ======= Sponsors Section ======= -->
    <section id="sponsors" class="section-with-bg wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Satisfied Clients </h2>
        </div>

        <div class="row no-gutters sponsors-wrap clearfix">

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/1.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/2.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/3.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/4.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/5.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/6.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/7.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="sponsor-logo">
              <img src="assets/img/sponsors/8.png" class="img-fluid" alt="">
            </div>
          </div>

        </div>

      </div>

    </section><!-- End Sponsors Section -->

   

    <!-- ======= Subscribe Section ======= -->
    <section id="subscribe">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Subcribe for our newsletter so you can recieve update from us</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section><!-- End Subscribe Section -->

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>