<?php $this->load->view('home/header'); ?>

  <main id="main">

 

  <!-- ======= About Section ======= -->
        <div class="section-header"  style="margin-top: 8%;">
          <h2><?php if(!empty($vacancy['name'])){ echo $vacancy['name']; }?></h2>
</div>
<!-- ======= About Section ======= -->
<div class="section">
    <section id="">
      <div class="container">

        <div class="row serv-cols">

          <div class="col-md-7 wow">
             <!--<div>-->
             <!--   <img style="max-width: 100%;height: auto;" src="<?php echo base_url().'assets/uploads/vacancy/'.$vacancy['image']; ?>"/>-->
             <!--</div> -->
            <div class="text-left">
                <h2 style="text-align: left;font-weight: 600;text-transform: uppercase;margin: 15px 0;"><?php if(!empty($vacancy['name'])){ echo $vacancy['name']; }?></h2>
                <h6>Uploaded Date :  <?php
                  $fromdate = $vacancy['date'];
                  $newfromdate = date("m-d-Y", strtotime($fromdate));
                  echo $newfromdate;
                  ?></h6>
                  <h7 style="font-size:16px;color:black;"><?php if(!empty($vacancy['content'])){ echo $vacancy['content']; }?></h7>
            </div>
          </div>
            <div class="col-md-5">
              <div class="form">
                  <form action="contactform.php" method="post" class="php-email-form">
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                        <div class="validate"></div>
                      </div>
                      <div class="form-group col-md-6">
                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required/>
                        <div class="validate"></div>
                      </div>
                    </div>
                    <div class="form-group">
                      <input type="number" class="form-control" name="subject" id="subject" placeholder="Phone Number" data-rule="minlen:4" data-msg="" required/>
                      <div class="validate"></div>
                    </div>
                    <div class="form-group">
                      <label>Upload Cv<br>
                        <input type="file" class="file_input"  id="file" accept=".txt, .docx, .doc, .pdf, .xlx, .xl, .ppt, .pptx" required=""></label>
                      <div class="validate"></div>
                    </div>
                    <div class="text-center"><button type="button" name="submit"  class="sendmail">Apply now</button></div>
                  </form>
                </div>
        </div>
        </div>
        

      </div>
    </section><!-- End About Section -->


    <!-- ======= Subscribe Section ======= -->
    <section id="subscribe">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Subcribe for our newsletter so you can recieve update from us</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section><!-- End Subscribe Section -->

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>
<script>
    $('button.sendmail').click(function(e)
    {
        e.preventDefault();
        var name = $('input#name').val();
        var email = $('input#email').val();
        var subject = $('input#subject').val();
        var file = $('#file')[0].files[0];
        var fd=new FormData();
        fd.append('name',name);
        fd.append('email',email);
        fd.append('subject',subject);
        fd.append('file',file);
        $.ajax({
             url:'<?php echo base_url();?>home/sendCV',
             method:"POST",  
             data:fd,  
             contentType: false,  
             cache: false,  
             processData:false,  
             dataType: "json",
             success:function(response)  
             {          
                var result = jQuery.parseJSON(JSON.stringify(response));
                console.log(result);
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
             }
        }); 
    });
</script>        