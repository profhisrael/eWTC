<?php $this->load->view('home/header'); ?>

  <main id="main">

  <!-- ======= About Section ======= -->
        <div class="section-header" style="margin-top: 8%;">
          <h2>Contact Form</h2>
</div>
<!-- ======= About Section ======= -->
<div class="section">
    <section id="">
      <div class="container">

        <div class="row serv-cols">

            <div class="col-md-12">
              <div class="form">
                  <form action="contactform.php" method="post" class="php-email-form">
                    <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required/>
                            <div class="validate"></div>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required/>
                            <div class="validate"></div>
                          </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                          <input type="text" class="form-control" name="subject" id="subject" placeholder="Please enter at least 8 chars of subject" required/>
                          <div class="validate"></div>
                        </div>
                        <div class="form-group col-md-6">
                          <input type="text" class="form-control" name="number" id="number" placeholder="Please enter phone number"  required/>
                          <div class="validate"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                      <textarea class="form-control" name="message" id="message"rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" required></textarea>
                      <div class="validate"></div>
                    </div>
                    <div class="text-center"><button type="button" name="submit"  class="sendmail">Send Message</button></div>
                  </form>
                </div>
        </div>
        </div>
        

      </div>
    </section><!-- End About Section -->

<br><br>
    <!-- ======= Subscribe Section ======= -->
    <section id="subscribe">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Subcribe for our newsletter so you can recieve update from us</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section><!-- End Subscribe Section -->

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>
<script>
    $('button.sendmail').click(function(e)
    {
        e.preventDefault();
        var name = $('input#name').val();
        var email = $('input#email').val();
        var subject = $('input#subject').val();
        var message = $('textarea#message').val();
        var number = $('input#number').val();  
        var fd=new FormData();
        fd.append('name',name);
        fd.append('email',email);
        fd.append('subject',subject);
        fd.append('message',message);
        fd.append('number',number);
        
        $.ajax({
             url:'<?php echo base_url();?>home/sendContact',
             method:"POST",  
             data:fd,  
             contentType: false,  
             cache: false,  
             processData:false,  
             dataType: "json",
             success:function(response)  
             {          
                var result = jQuery.parseJSON(JSON.stringify(response));
                console.log(result);
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
             }
        }); 
    });
</script>        