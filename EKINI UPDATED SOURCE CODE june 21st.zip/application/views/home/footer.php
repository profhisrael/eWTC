<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- Vendor JS Files -->
  <!--<script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>-->
  <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/superfish/superfish.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/hoverIntent/hoverIntent.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

  <script>if( window.self == window.top ) { (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){ (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o), m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m) })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga'); ga('create', 'UA-55234356-4', 'auto'); ga('send', 'pageview'); } </script>
</body>


<!-- ===== Footer Here ==== -->
<!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="<?php echo base_url(); ?>assets/img/logo.png" alt="ekiniwhitetulipconsulting">
            <p align="justify">Ekini White Tulip Consulting Limited came into the human capital development and training sector in 2012  with a firm believe that services to the sector can be much professional, result-oriented and more responsive to your specific needs. Right now, there are too many generalists, forms rather than substance and delivery rather than value. We are here primarily to add concrete value to your organization.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Services</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/allcourses">Training</a></li>
              <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url(); ?>home/allvacancy">Job recruitment</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/service">Management Solutions </a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/service">Marketing Solutions </a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/service">Human Capital Development</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/about">About Us</a></i>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/loadContact">Contact Us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/faq">Faqs</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/term">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="<?php echo base_url(); ?>home/policy">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
             Adebola House(Suite 100, Rear Wing) <br>
            38 Opebi road <br>
            Ikeja Lagos 23401 <br> 
              Nigeria<br>
              <strong>Phone:</strong> +234 802-9606-103<br>
              <strong>Email:</strong> <a href="https://ekiniwhitetulipconsulting@gmail.com">[email&#160;protected]</a><br>
            </p>

            <div class="social-links">
              <!--<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>-->
              <a href="https://www.facebook.com/EkiniWhiteTulipConsulting" class="facebook"><i class="fa fa-facebook"></i></a>
            <!--  <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>-->
              <a href="https://www.google.com/maps/dir//6.55516,3.34512/@6.5545543,3.2746125,12z/data=!3m1!4b1!4m4!4m3!1m1!4e2!1m0" class="google-plus"><i class="fa fa-map-marker"></i></a>
              <a href="https://www.linkedin.com/company/white-tulip-consulting-ltd" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>eWTC</strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by <a href="">Profhisrael</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- Vendor JS Files -->
  <!--<script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>-->
  <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/superfish/superfish.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/hoverIntent/hoverIntent.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

  <script>if( window.self == window.top ) { (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){ (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o), m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m) })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga'); ga('create', 'UA-55234356-4', 'auto'); ga('send', 'pageview'); } </script>
</body>


</html>

<!-- ====== I end my Footer Here ==== -->
</html>
