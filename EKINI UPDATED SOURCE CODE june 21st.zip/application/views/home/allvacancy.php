<?php $this->load->view('home/header'); ?>

  <main id="main">


  <!-- ======= About Section ======= -->
        <div class="section-header" style="margin-top: 8%;">
          <h2>Vacancies</h2>
        </div>
         <!-- ======= Training and upcoming Pogrammes ======= -->
         <div class="container">
            <section id="trainings" class="">

        <div class="row">
            <!--<div id="wrapper">-->
            <!--        <div class="contents" style="">-->
          <?php foreach($vacancy as $row){ ?>
          <div class="col-sm-6 col-md-3">
            <div class="training" style="    padding: 4%;">
              <div class="training-img">
                <img style="height: 250px;width: 100%;" src="<?php echo base_url().'assets/uploads/vacancy/'.$row['image'] ?>" alt="training 1" class="img-fluid">
              </div>
              <h3 align="left" class="w3-padding-small w3-small"><a href="<?php echo base_url().'home/singlevacancy/'.$row['id'] ?>"><b><?php echo $row['title'] ?></b></a></h3>
              <span class="fa fa-calendar w3-padding-small w3-lage w3-text-black w3-small"><b>
              Date  <?php
              $fromdate = $row['date'];
              $newfromdate = date("m-d-Y", strtotime($fromdate));
              
              echo $newfromdate;
              ?></b></span>
    
              <div class="w3-padding-small w3-text- w3-padding-top w3-small" align="justify" style="background-color:#060c22; color:white;"><b>
              <?php
              echo "<strong class='text-white'>".substr($row['content'],0,30)."</strong>";
              ?></b></div><br>  
                <a href="<?php echo base_url().'home/singlevacancy/'.$row['id'] ?>"><center><span class="w3-btn w3-red w3-round-xxlarge">Apply and Details</span></center><br>
                </a>
            </div>

          </div>
          <?php } ?>
      <!--      </div>-->
      <!--</div>-->
        </div>
      </div>

    </section><!-- End Training  -->
        </div>
        <!-- ======= About Section ======= -->



    <!-- ======= Subscribe Section ======= -->
    <section id="subscribe">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Subcribe for our newsletter so you can recieve update from us</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section><!-- End Subscribe Section -->

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>
<script>
$(document).ready(function()
 {
   $("#tab").pagination({
   items: 4,
   contents: 'contents',
   previous: 'Previous',
   next: 'Next',
   position: 'bottom',
   });
});
</script>
