<?php $this->load->view('home/header'); ?>
  

  <!-- ======= About Section ======= -->
        <div class="section-header" style="margin-top: 8%;">
          <h2><?php if(!empty($course['name'])){ echo $course['name']; }?></h2>
</div>
<!-- ======= About Section ======= -->
<div class="section">
    <section id="">
      <div class="container">

        <div class="row serv-cols">

          <div class="col-md-7 wow">
             <!--<div>-->
             <!--   <img style="max-width: 100%;height: auto;" src="<?php echo base_url().'assets/uploads/course/'.$course['image']; ?>"/>-->
             <!--</div> -->
            <div class="text-left">
                <h2 style="text-align: left;font-weight: 600;text-transform: uppercase;margin: 15px 0;"><?php if(!empty($course['name'])){ echo $course['name']; }?></h2>
                <h6>Date :  <?php
                  $fromdate = $course['fromdate'];
                  $newfromdate = date("m-d-Y", strtotime($fromdate));
                  $todate = $course['todate'];
                  $newtodate = date("m-d-Y", strtotime($todate));
                  echo $newfromdate."    ".$newtodate;
                  ?></h6>
                  <h7 style="font-size:16px;color:black;"><?php if(!empty($course['content'])){ echo $course['content']; }?></h7>
            </div>
          </div>
            <div class="col-md-5">
              <div class="form">
                  <form action="contactform.php" method="post" class="php-email-form">
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required/>
                        <div class="validate"></div>
                      </div>
                      <div class="form-group col-md-6">
                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required/>
                        <div class="validate"></div>
                      </div>
                    </div>
                    <div class="form-group">
                      <input type="number" class="form-control" name="number" id="number" placeholder="Phone Number" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required/>
                      <div class="validate"></div>
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" value="<?php if(!empty($course['name'])){ echo $course['name']; }?>" required/>
                      <div class="validate"></div>
                    </div>
                    <div class="form-group">
                      <textarea class="form-control" name="message" id="message"rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Additional message" required></textarea>
                      <div class="validate"></div>
                    </div>
                    <div class="text-center"><button type="button" name="submit"  class="sendmail">Apply now</button></div>
                  </form>
                </div>
        </div>
        </div>
        

      </div>
    </section><!-- End About Section -->


    <!-- ======= Subscribe Section ======= -->
    <section id="subscribe">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Subcribe for our newsletter so you can recieve update from us</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section><!-- End Subscribe Section -->

    

  </main><!-- End #main -->
<?php $this->load->view('home/footer'); ?>
<script>
    $('button.sendmail').click(function(e)
    {
        e.preventDefault();
        var name = $('input#name').val();
        var email = $('input#email').val();
         var number = $('input#number').val();
        var subject = $('input#subject').val();
        var message = $('textarea#message').val();
           
        var fd=new FormData();
        fd.append('name',name);
        fd.append('email',email);
        fd.append('number',number);
        fd.append('subject',subject);
        fd.append('message',message);
        $.ajax({
             url:'<?php echo base_url();?>home/sendApplication',
             method:"POST",  
             data:fd,  
             contentType: false,  
             cache: false,  
             processData:false,  
             dataType: "json",
             success:function(response)  
             {          
                var result = jQuery.parseJSON(JSON.stringify(response));
                console.log(result);
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
             }
        }); 
    });
</script>        