<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <form class="aboutform" style="margin: 10 auto;"> 
        <div class="col-12 m-0 mt-3 p-0">
			<label for="" class="col-sm-2 control-label m-0 p-0">Job title</label>
			<div class="col-sm-6 m-0 p-0">
                <input type="hidden" autocomplete="off" class="form-control" name="id" id="id" 
                value="<?php if(!empty($vacancy['id'])){ echo $vacancy['id']; }?>" required>
				<input type="text" autocomplete="off" class="form-control" name="title" id="title" value="<?php if(!empty($vacancy['title'])){ echo $vacancy['title']; }?>" required>
			</div>
		</div>
		<div class="col-12 m-0 mt-3 p-0">
			<label for="">Description</label>
		    <div class="w3-container m-0 p-0">
            	<textarea id="contents" required><?php if(!empty($vacancy['content'])){ echo $vacancy['content']; }?></textarea>
            </div>
		</div>
		
		<div class="col-12 m-0 mt-3 p-0">
			<label for="" class="col-sm-2 m-0 p-0 control-label">Image</label>
			<div class="col-sm-6 m-0 p-0">
                <input type="hidden" id="photovalue" value="<?php if(!empty($vacancy['image'])){ echo $vacancy['image']; } ?>">
                <?php if(!empty($vacancy['image'])){ ?>
                <img width="30%" style="margin: 1%;" src="<?php echo base_url().'assets/uploads/vacancy/'.$vacancy['image']; ?>"><br>
				<?php } ?>
                <input type="file" id="photo" name="photo" ><br>(Only jpg, jpeg, gif and png are allowed)
			</div>
		</div>
		<br>
		<button type="button" class="btn btn-primary submit" name="form1">Submit</button>
	    </form>
	</div>

</div>        
<!-- Page Content -->
 

<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>

</html>

<script>
	
	$(document).ready(function() {
        $('#contents').summernote('code');
	});
    
   $('.submit').on('click', function (e) {
        var id = $('#id').val();
        var title = $('#title').val();
        var content = $('#contents').summernote('code');
        var image = $('#photo')[0].files[0];
        var photovalue =  $('input#photovalue').val();
        var fd = new FormData();
        fd.append('id',id);
        fd.append('title',title);
        fd.append('content',content);
        fd.append('image',image);
        fd.append('photovalue',photovalue);
        $.ajax
        ({
     
            url:'<?php echo base_url(); ?>admin/updateVacancy',
            type:"POST",  
            data:fd,  
            contentType: false,  
            cache: false,  
            processData:false,  
            dataType: "json",
            success: function(response)
            {
                var result = jQuery.parseJSON(JSON.stringify(response));
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
            }
        });

	});
</script>