<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
				<div class="table-responsive">
					<table id="dataTable" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th width="50">SL</th>
								<th>CV</th>
								<th>Name</th>
								<th>Email</th>
								<th>Number</th>
								<th>Date</th>
								<th width="150">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=0; foreach ($cv as $row) { $i++; ?>
								<tr>
									<td style="width:70px;"><?php echo $i; ?></td>
									<td><a href="<?php echo base_url().'admin/downloadCV/'.$row['id']; ?>"><?php echo $row['cv']; ?></a></td>
									<td><?php echo $row['name']; ?></td>
									<td><?php echo $row['email']; ?></td>
									<td><?php echo $row['number']; ?></td>
								
									<td><?php echo $row['date']; ?></td>
									
									<td style="width:100px;">
										 <a class="btn btn-danger btn-xs deleteButton"  data-id="<?php echo $row['id'] ?>" style="padding: 5%;font-size: 100%;color: white;"><i class="fa fa-trash" aria-hidden="true"></i></a>
	                                </td>
								</tr>
							<?php } ?>							
						</tbody>
					</table>
				</div>
		</div>
	</div>
</div>        
<!-- Page Content -->
 

<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>

</html>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/admin/datatable/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/datatable/css/jquery.dataTables.css">
  <script type="text/javascript">
$(document).ready(function() {
  $('#dataTable').DataTable();

});
</script>
<script>
    $("a.deleteButton").click(function()
    {
        var id = $(this).attr('data-id');
        var r = confirm("Are you sure !");
		if (r == true)
		{
		 	$.ajax
		 	({
			     type:'POST', 
	             url:'<?php echo base_url();?>admin/deleteCV',
	             data:{'id':id},  
	             dataType:'json',
	             success:function(response)  
	             {          
	                var result= jQuery.parseJSON(JSON.stringify(response));
	                var typeOfResponse=result['type'];
	                var res=result['msg'];
	                if(typeOfResponse==0)
	                {
	                   alert(res);
	                }
	                else if(typeOfResponse==1)
	                {
	                   alert(res);
	                   location.reload(true);
	                }
	             }
        	}); 
		}
		else
		{
		  return false;
		}
    });
</script>