<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <form class="aboutform" style="margin: 10 auto;"> 
        <div class="col-12 m-0 mt-3 p-0">
			<label for="" class="col-sm-2 control-label m-0 p-0">Course</label>
			<div class="col-sm-6 m-0 p-0">
                <input type="hidden" autocomplete="off" class="form-control" name="id" id="id" 
                value="<?php if(!empty($course['id'])){ echo $course['id']; }?>" required>
				<input type="text" autocomplete="off" class="form-control" name="title" id="title" value="<?php if(!empty($course['name'])){ echo $course['name']; }?>" required>
			</div>
		</div>
		<div class="col-12 m-0 mt-3 p-0">
			<label for="">Description</label>
		    <div class="w3-container m-0 p-0">
            	<textarea id="contents" required><?php if(!empty($course['content'])){ echo $course['content']; }?></textarea>
            </div>
		</div>
		<div class="col-12 m-0 mt-3 p-0">
			<label for="">Location</label>
		    <div class="col-12 m-0 p-0">
            	<textarea id="location" row="3" style="width:50%" required><?php if(!empty($course['location'])){ echo $course['location']; }?></textarea>
            </div>
		</div>
		<div class="col-12 m-0 p-0">
            <div class="row m-0 mt-3 p-0">
                <div class="col-md-6 col-sm-12  m-0 p-0">
            	    <label for="">From Date</label><br>
                    <input type="date" id="fromdate" value="<?php if(!empty($course['fromdate'])){ echo $course['fromdate']; }?>" required>
                </div>
                <div class="col-md-6 col-sm-12  m-0 p-0">
                    <label for="">To Date</label><br>
            	    <input type="date" id="todate" value="<?php if(!empty($course['todate'])){ echo $course['todate']; }?>" required>
                </div>
            </div>
		</div>
		<div class="col-12 m-0 mt-3 p-0">
			<label for="" class="col-sm-2 m-0 p-0 control-label">Image</label>
			<div class="col-sm-6 m-0 p-0">
                <input type="hidden" id="photovalue" value="<?php if(!empty($course['image'])){ echo $course['image']; } ?>">
                <?php if(!empty($course['image'])){ ?>
                <img width="30%" style="margin: 1%;" src="<?php echo base_url().'assets/uploads/course/'.$course['image']; ?>"><br>
				<?php } ?>
                <input type="file" id="photo" name="photo" ><br>(Only jpg, jpeg, gif and png are allowed)
			</div>
		</div>
		<br>
		<button type="submit" class="btn btn-primary submit" name="form1">Submit</button>
	    </form>
	</div>

</div>        
<!-- Page Content -->
 

<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>

</html>

<script>
	
	$(document).ready(function() {
        $('#contents').summernote('code');
	});
    
   $('.aboutform').on('submit', function (e) {
        var id = $('#id').val();
        var name = $('#title').val();
        var location = $('textarea#location').val();
        var fromdate = $('#fromdate').val();
        var todate = $('#todate').val();
        var content = $('#contents').summernote('code');
        var image = $('#photo')[0].files[0];
        var photovalue =  $('input#photovalue').val();
        var fd = new FormData();
        fd.append('id',id);
        fd.append('name',name);
        fd.append('location',location);
        fd.append('fromdate',fromdate);
        fd.append('todate',todate);
        fd.append('content',content);
        fd.append('image',image);
        fd.append('photovalue',photovalue);
        $.ajax
        ({
     
            url:'<?php echo base_url(); ?>admin/updateCourse',
            method:"POST",  
            data:fd,  
            contentType: false,  
            cache: false,  
            processData:false,  
            dataType: "json",
            success: function(response)
            {
                var result = jQuery.parseJSON(JSON.stringify(response));
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
            }
        });

	});
</script>