<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>
	<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Content Row -->
          <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Profile</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Edit Profile</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="profilepic-tab-tab" data-toggle="tab" href="#profilepic" role="tab" aria-controls="profilepic" aria-selected="false">Change Profile Picture</a>
            </li>
          </ul>
          	<div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
	                <div class="item-title mt-5">
	                    <h3>User Profile</h3>
	                </div>
	                <div class="row mb-4">
	                    <div class="col-xl-4 col-lg-4">
	                      <div class="card card-profile">
	                            <div class="card-avatar">
	                                <a href="#">
	                                    <img class="img" src="<?php echo base_url().'assets/uploads/profile/'.$profile['image']; ?>" width="100%">
	                                </a>
	                            </div>
	                        </div>
	                    </div>
		                <div class="col-lg-8 col-xl-8">
		                      <div class="form-main" style="margin: 0;">
		                    	<form style="padding: 33px 0;">
			                      	<div class="row">
				                        <div class="col-md-6">
				                        	<div class="form-group">
				                        		<label><p>Name</p><input readonly="" placeholder="" type="text" value="<?php echo $profile['name']; ?>" name=""></label>
				                    		</div>
				                    	</div>

				                        <div class="col-md-6">
				                        	<div class="form-group"><label><p>Phone NO</p><input readonly="" placeholder="" type="text" value="<?php echo $profile['phone'];?>" name=""></label>
				                        	</div>
				                        </div>

				                        <div class="col-md-6">
				                        	<div class="form-group"><label><p>Adress</p><input readonly="" placeholder="" type="text" value="<?php echo $profile['address'];?>" name=""></label>
				                        	</div>
				                        </div>

				                        <div class="col-md-6">
				                        	<div class="form-group"><label><p>Email</p><input readonly="" placeholder="" type="text" value="<?php echo $profile['email'];?>" name=""></label>
				                        	</div>
				                        </div>

				                        <div class="col-md-6">
				                        	<div class="form-group"><label><p>Password</p><input placeholder="" type="password" readonly value="<?php echo $profile['password'];?>" name=""></label>
				                        	</div>
				                        </div>
			                    	</div>    
		                   		</form>
		                  	  </div>
		                </div>
	                </div>
				</div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  <div class="item-title mt-5">
                    <h3>Edit Profile</h3>
                  </div>
                  <div class="form-main">
                    
                  <form id="userForm" action="" method="post">
                      <div class="row">
                        <div class="col-md-6">
                        	<div class="form-group">
                        		<label><p>Name</p><input placeholder="" type="text" value="<?php echo $profile['name'];?>"  id="username" name="name"></label>
                        	</div>
                          <?php echo form_error('name'); ?>
						</div>

                        <div class="col-md-6">
                        	<div class="form-group">
                        		<label><p>Phone</p><input placeholder="" type="text" value="<?php echo $profile['phone'];?>"  id="phone" name="phoneno" required>
                        		</label>
                        	</div>
                          <?php echo form_error('phoneno'); ?>
						</div>

                        <div class="col-md-6">
                        	<div class="form-group">
                        		<label><p>Address</p><input placeholder="" type="text" value="<?php echo $profile['address'];?>"  id="address" required>
                        		</label>
                        	</div>
                          <?php echo form_error('address'); ?>
						</div>

                        <div class="col-md-6">
                        	<div class="form-group">
                        		<label><p>Email</p><input placeholder="" type="email" value="<?php echo $profile['email'];?>"  id="email" name="email" required>
                        		</label>
                        	</div>
                          <?php echo form_error('email'); ?>
						</div>

                        <div class="col-md-6">
                        	<div class="form-group">
                        		<label><p>Password</p><input placeholder="" type="text" value="<?php echo $profile['password'];?>"  id="password" name="password" required>
                        		</label>
                        	</div>
                          <?php echo form_error('password'); ?>
						</div>
						<div class="col-md-12 pt-2">
							<button style="padding: 11px 50px;     margin-top: 19px;" type="submit" class="submit-button">Update</button>
						</div>
                    </div>
				  </form>
                  </div>
                </div>
                <div class="tab-pane fade" id="profilepic" role="tabpanel" aria-labelledby="profilepic-tab">
                  <div class="item-title mt-5">
                    <h3>Change Profile Picture</h3>
                  </div>
                  <div class="form-main">
                    <form id="profilepicture">
						<div class="row">
                      		<div class="col-md-12 pt-2 text-left">

	                              <label class="image-main">
	                                <input type='file' name="userfile" onchange="readURL(this);" id="photo" required />
	                                <span><i class="fas fa-camera"></i></span>
	                                <img id="blah" width="101" src="<?php echo base_url().'assets/uploads/profile/'.$profile['image']; ?>" alt="your image" />
	                              </label>
	                               <script type="text/javascript">function readURL(input) { if (input.files && input.files[0]) { var reader = new FileReader(); reader.onload = function (e) { $('#blah') .attr('src', e.target.result); }; reader.readAsDataURL(input.files[0]); } }

	                             </script>
                             </div>

                              <div class="col-md-12 pt-2">
                                	<label><p style="color: red;">Note:Chose Image by clicking on Photo <?php //echo $user['id']; ?></p></label>
                              </div>


                             <div class="col-md-12 pt-2">
                             	<button style="padding: 11px 50px;     margin-top: 19px;" type="submit" class="submit-button">Update</button>
                             </div>
                        </div>
					</form>
                  </div>
                </div>
            </div>   
           


        </div>
<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>
</html>
<script>
      $('#userForm').on('submit', function (e) {

        var name = $('#username').val();
        var address = $('#address').val();
        var phone = $('#phone').val();
        var password = $('#password').val();
        var email = $('#email').val();
        var fd = new FormData();
        fd.append('address',address);
        fd.append('name',name);
        fd.append('phone',phone);
        fd.append('password',password);
        fd.append('email',email);
  		$.ajax
        ({
     
            url:'<?php echo base_url(); ?>admin/updateprofileinfo',
            method:"POST",  
            data:fd,  
            contentType: false,  
            cache: false,  
            processData:false,  
            dataType: "json",
            success: function(response)
            {
                var result = jQuery.parseJSON(JSON.stringify(response));
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
            }
        });
    });    
</script>
<script>
      $('#profilepicture').on('submit', function (e) {
        var image = $('#photo')[0].files[0];
        var fd = new FormData();
        fd.append('image',image);
  		$.ajax
        ({
     
            url:'<?php echo base_url(); ?>admin/updateprofilepicture',
            method:"POST",  
            data:fd,  
            contentType: false,  
            cache: false,  
            processData:false,  
            dataType: "json",
            success: function(response)
            {
                var result = jQuery.parseJSON(JSON.stringify(response));
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
            }
        });
    });    
</script>    