<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>

<div class="container-fluid">

    <div class="form-main">
        <div class="item-title">
            <h3>Upload Images</h3>
        </div>
        <form action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-10">
                    <div class="form-group">
                        <label><p>Upload Multiple Images</p>
                        <input type="file" class="file_input" multiple="multiple" name="file_input[]"  accept=".png, .jpg, .jpeg" required ></label>
                    </div>
                </div>
                <div class="col-md-2 pt-2 text-right">
                    <button style="padding: 11px 50px;margin-top: 19px;" type="button" id="save" class="submit-button">Upload</button>
                </div>
            </div>
        </form>
    </div>

    <div class="form-main">
       <div class="item-title">
        <h3>All Upload Images</h3>
      </div>
        <div class="row">
            <div class="col-md-12">
                  <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th style="width:10%; text-align: center;">No.</th>
                              <th>Image</th>
                              <th style="width:120px; text-align: center;">Action</th>
                            </tr>
                          </thead>
                          <tfoot>
                            <tr>
                              <th style="width:10%; text-align: center;">No.</th>
                              <th>Image</th>
                              <th style="width:120px; text-align: center;">Action</th>
                            </tr>
                          </tfoot>
                          <tbody>
                          <?php $a=1; ?>
                          <?php foreach ($gallery as $row) : ?>
                            <tr>
                              <td><?php echo $a++; ?></td>
                              <td><img src="<?php echo base_url('assets/uploads/gallery/').$row['image']; ?>" width="50px" height="50px" /></td>
                              <td style="text-align: center;"><span class="btn btn-danger del"><a  style="color: white;" class="fa fa-trash-alt deletedata"  data-id="<?php echo $row['id'] ?>"></a></span></td>
                            </tr>
                          <?php endforeach; ?>
                          </tbody>
                        </table>
                  </div>
            </div>
        </div>
    </div>

</div>


<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>

</html>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/admin/datatable/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/datatable/css/jquery.dataTables.css">
<script type="text/javascript">
$(document).ready(function() {
  $('#dataTable').DataTable();

});
</script>
<script>
$(document).ready(function()
{

    $('#save').on('click', function()
    {
        var fileInputs = $('.file_input');
        var formData = new FormData();
        $.each(fileInputs, function(i,fileInput){
                if( fileInput.files.length > 0 )
                {
                    $.each(fileInput.files, function(k,file){
                        formData.append('images[]', file);
                    });
                }
                else
                {
                    alert('No Files Selected');
                    return false;
                }
        });
        $.ajax({
                method: 'post',
                url:"<?php echo base_url(); ?>admin/uploadGallery",
                data: formData,
                dataType: 'json',
                contentType: false,
                processData: false,
                success: function(response)
                {
                    var result = jQuery.parseJSON(JSON.stringify(response));
                    console.log(result);
                    var typeOfResponse=result['type'];
                    var res=result['msg'];
                    if(typeOfResponse==0)
                    {
                        alert(res);
                    }
                    else if(typeOfResponse==1)
                    {
                        alert(res);
                        location.reload(true);
                    }
                }
        });
    });
    $('.deletedata').click(function()
    {
        var id = $(this).attr("data-id");
        var r = confirm("Are you sure!");
        if (r == true)
        {
            $.ajax
            ({
                url:"<?php echo base_url() ?>admin/deleteGallery",
                type: "post",
                dataType: 'json',
                data: {id:id},
                success:function(response)
                {
                    var result = jQuery.parseJSON(JSON.stringify(response));
                    var typeOfResponse=result['type'];
                    var res=result['msg'];
                    if(typeOfResponse==0)
                    {
                        alert(res);
                    }
                    else if(typeOfResponse==1)
                    {
                        alert(res);
                        location.reload(true);
                    }
                }
            });
        }
        else
        {
          return false;
        }
    });
});
</script>


        
