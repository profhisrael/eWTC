   <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            
            <script type="text/javascript">
            	const now = new Date();
            	document.write(now);
            </script><br> <br><span>Copyright &copy; eWTC 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->
