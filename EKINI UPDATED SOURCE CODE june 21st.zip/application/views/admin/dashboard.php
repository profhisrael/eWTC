<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>
           
        <!-- Begin Page Content -->
        <div class="container-fluid">

          

          <!-- Content Row -->
          <div class="row">

            <!-- Stats panel -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color:blue;">Total Courses</div>
                      <div class="h5 mb-0 font-weight-bold" style="color:black;"><?php if($coures){ echo $coures; }else{ echo "0"; } ?></div>
                    </div>
                  
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color:blue;">Total Active Job vacancy</div>
                      <div class="h5 mb-0 font-weight-bold" style="color:black"><?php if($vacancy){ echo $vacancy; }else{ echo "0"; } ?></div>
                    </div>
                  
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color:red;">Submitted Application</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold" style="color:black;"><?php if($application){ echo $application; }else{ echo "0"; } ?></div>
                      </div>
                  </div>
                        
                    </div>
                 
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color:red;">Submitted CV</div>
                      <div class="h5 mb-0 font-weight-bold" style="color:black;"><?php if($cv){ echo $cv; }else{ echo "0"; } ?></div>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Content Row -->

        

    <div>
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Contact Us (Messages)</h6>
                </div>
                <div class="card-body">
                  <div class="text-center">
                   <div class="row">
        <div class="col-md-12">
				<div class="table-responsive">
				<table id="dataTable" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th width="50">SL</th>
								
								<th>Name</th>
								<th>Email</th>
								<th>Number</th>
								<th>Subject</th>
								<th>Message</th>
								<th>Date</th>
								<th width="150">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=0; foreach ($contact as $row) { $i++; ?>
								<tr>
									<td style="width:70px;"><?php echo $i; ?></td>
						
									<td><?php echo $row['name']; ?></td>
									<td><?php echo $row['email']; ?></td>
									<td><?php echo $row['number']; ?></td>
									<td><?php echo $row['subject']; ?></td>
									<td><?php echo $row['message']; ?></td>
									<td><?php echo $row['date']; ?></td>
									
									<td style="width:100px;">
										 <a class="btn btn-danger btn-xs deleteButton"  data-id="<?php echo $row['id'] ?>" style="padding: 5%;font-size: 100%;color: white;"><i class="fa fa-trash" aria-hidden="true"></i></a>
	                                </td>
								</tr>
							<?php } ?>							
						</tbody>
					</table>
				</div>
		</div>
	</div>
                  </div>
                  <p>The Contact Us section Messages will be here</p>
                  
                </div>
              </div>

             
      </div>
      <!-- End of Main Content -->
  
<?php include("footer.php"); ?>
      

</body>

</html>
 <script type="text/javascript">
$(document).ready(function() {
  $('#dataTable').DataTable();

});
</script>
<script>
    $("a.deleteButton").click(function()
    {
        var id = $(this).attr('data-id');
        var r = confirm("Are you sure !");
		if (r == true)
		{
		 	$.ajax
		 	({
			     type:'POST', 
	             url:'<?php echo base_url();?>admin/deleteContact',
	             data:{'id':id},  
	             dataType:'json',
	             success:function(response)  
	             {          
	                var result= jQuery.parseJSON(JSON.stringify(response));
	                var typeOfResponse=result['type'];
	                var res=result['msg'];
	                if(typeOfResponse==0)
	                {
	                   alert(res);
	                }
	                else if(typeOfResponse==1)
	                {
	                   alert(res);
	                   location.reload(true);
	                }
	             }
        	}); 
		}
		else
		{
		  return false;
		}
    });
</script>
