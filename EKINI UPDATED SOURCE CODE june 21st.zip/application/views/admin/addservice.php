<?php $this->load->view("admin/script"); ?>
<?php $this->load->view("admin/header"); ?>
<?php $this->load->view("admin/sidebar"); ?>
<?php $this->load->view("admin/topbar"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <form class="aboutform" style="margin: 10 auto;"> 
		<div class="col-12 m-0 p-0">
			<label for="">About us Content</label>
		    <div class="w3-container m-0 p-0">
		        <input type="hidden" value="<?php echo servicecontent['id']; ?>" id="id"/>
            	<textarea id="contents"><?php echo servicecontent['servicepage']; ?></textarea>
            </div>
		</div><br>
		<button type="submit" class="btn btn-primary submit" name="form1">Submit</button>
	    </form>
	</div>

</div>        
<!-- Page Content -->
 

<!-- Page Wrapper -->
</div>
  
<?php include("footer.php"); ?>
</body>

</html>

<script>
	
	$(document).ready(function() {
        $('#contents').summernote('code');
	});
    
   $('.aboutform').on('submit', function (e) {

         e.preventDefault();
         var id = $('#id').val();
         var textareaVal = $('#contents').summernote('code');
         $.ajax
        ({
            type:'POST',
            url:'<?php echo base_url(); ?>admin/insertAboutcontent',
            data:{'textareaVal':textareaVal,'id':id},
            dataType:'json',
            success: function(response)
            {
                var result = jQuery.parseJSON(JSON.stringify(response));
                var typeOfResponse=result['type'];
                var res=result['msg'];
                if(typeOfResponse==0)
                {
                    alert(res);
                }
                else if(typeOfResponse==1)
                {
                    alert(res);
                    location.reload(true);
                }
            }
        });

	});
</script>